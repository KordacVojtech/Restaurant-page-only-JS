const div = document.getElementById('content');
const homeBtn = document.createElement('button');
const menuBtn = document.createElement('button');
const contactBtn = document.createElement('button');
const menuDiv = document.createElement('div');


menuDiv.style.display = 'flex';
menuDiv.style.justifyContent = 'center';
menuDiv.style.alignItems = 'center';
menuDiv.style.backgroundColor = 'rgb(79, 79, 79)';
menuDiv.style.marginBottom ='0px';


homeBtn.textContent = 'Home';
homeBtn.className = 'navBtn';
homeBtn.style.width = '50rem';
homeBtn.style.padding='1rem';
homeBtn.style.textShadow = '2px 2px 2px black';
homeBtn.style.marginLeft = '3rem';
homeBtn.style.marginRight = '3rem';
homeBtn.style.fontSize = '30px';
homeBtn.style.letterSpacing = '10px';
homeBtn.style.backgroundColor = 'rgb(79, 79, 79)';
homeBtn.style.color = 'white';
homeBtn.style.border = 'none';
homeBtn.style.outline = 'none';
homeBtn.style.cursor = 'pointer';

menuBtn.textContent = 'Menu';
menuBtn.className = 'navBtn';
menuBtn.style.width = '50rem';
menuBtn.style.textShadow = '2px 2px 2px black';
menuBtn.style.padding = '1rem';
menuBtn.style.marginLeft = '7rem';
menuBtn.style.marginRight = '7rem';
menuBtn.style.fontSize = '30px';
menuBtn.style.letterSpacing = '10px';
menuBtn.style.backgroundColor = 'rgb(79, 79, 79)';
menuBtn.style.color = 'white';
menuBtn.style.border = 'none';
menuBtn.style.outline = 'none';
menuBtn.style.cursor = 'pointer';

contactBtn.textContent = 'Contact us';
contactBtn.className = 'navBtn';
contactBtn.style.width = '50rem';
contactBtn.style.textShadow = '2px 2px 2px black';
contactBtn.style.padding = '1rem';
contactBtn.style.marginLeft = '3rem';
contactBtn.style.marginRight = '3rem';
contactBtn.style.fontSize = '30px';
contactBtn.style.letterSpacing = '10px';
contactBtn.style.backgroundColor = 'rgb(79, 79, 79)';
contactBtn.style.color = 'white';
contactBtn.style.border = 'none';
contactBtn.style.outline = 'none';
contactBtn.style.cursor = 'pointer';

homeBtn.addEventListener('click', ()=>{
    document.location.href = 'index.html';
})

menuBtn.addEventListener('click', ()=>{
    document.location.href = 'menu.html';
})

contactBtn.addEventListener('click', ()=>{
    document.location.href = 'contact.html';
})


const itemsDiv = document.createElement('div');

const pizza = document.createElement('div');
const burger = document.createElement('div');
const pasta = document.createElement('div');
const lasagne = document.createElement('div');

const pizzaTitle = document.createElement('h3');
const burgerTitle = document.createElement('h3');
const pastaTitle = document.createElement('h3');
const lasagneTitle = document.createElement('h3');

const pizzaItems = document.createElement('div');
const burgerItems = document.createElement('div');
const pastaItems = document.createElement('div');
const lasagneItems = document.createElement('div');

const cheese = document.createElement('p');
cheese.textContent = 'Cheese pizza';
cheese.style.color = 'white';
cheese.textAlign = 'center';
cheese.style.fontSize = '3rem';
cheese.style.textShadow = '2px 3px 3px black';
cheese.style.backgroundColor = 'black';

const pepperoni = document.createElement('p');
pepperoni.textContent = 'Pepperoni pizza';
pepperoni.style.color = 'white';
pepperoni.style.textAlign = 'center';
pepperoni.style.textShadow = '2px 3px 3px black';
pepperoni.style.backgroundColor = 'black';
pepperoni.style.fontSize = '3rem';

const cheeseburger = document.createElement('p');
cheeseburger.textContent = 'Cheeseburger';
cheeseburger.style.color = 'white';
cheeseburger.style.textShadow = '2px 3px 3px black';
cheeseburger.textAlign = 'center';
cheeseburger.style.fontSize = '2.9rem';
cheeseburger.style.backgroundColor = 'black';

const woodstock = document.createElement('p');
woodstock.textContent = 'Woodstock';
woodstock.style.color = 'white';
woodstock.style.fontSize = '3rem';
woodstock.style.textAlign = 'center';
woodstock.style.backgroundColor = 'black';
woodstock.style.textShadow = '2px 3px 3px black';

const spaghetti = document.createElement('p');
spaghetti.textContent = 'Spaghetti';
spaghetti.style.color = 'white';
spaghetti.style.textShadow = '5px 5px 3px black';
spaghetti.style.backgroundColor = 'black';
spaghetti.style.fontSize = '3rem';
spaghetti.textAlign = 'center';

const carbonara = document.createElement('p');
carbonara.textContent = 'Carbonara';
carbonara.style.color = 'white';
carbonara.style.textShadow = '5px 5px 3px black';
carbonara.style.backgroundColor = 'black';
carbonara.style.fontSize = '3rem';
carbonara.textAlign = 'center';

const meatLover = document.createElement('p');
meatLover.textContent = 'Meat lover';
meatLover.style.color = 'white';
meatLover.style.textShadow = '5px 5px 3px black';
meatLover.style.backgroundColor = 'black';
meatLover.style.fontSize = '3rem';
meatLover.textAlign = 'center';

const vegetarian = document.createElement('p');
vegetarian.textContent = 'Vegetarian';
vegetarian.style.color = 'white';
vegetarian.style.textShadow = '5px 5px 3px black';
vegetarian.style.backgroundColor = 'black';
vegetarian.style.fontSize = '3rem';
vegetarian.textAlign = 'center';

pizzaTitle.textContent = 'Pizza';
pizzaTitle.style.textShadow = '2px 3px 3px black';
burgerTitle.textContent = 'Burger';
burgerTitle.style.textShadow = '2px 3px 3px black';
pastaTitle.textContent = 'Pasta';
pastaTitle.style.textShadow = '2px 3px 3px black';
lasagneTitle.textContent = 'Lasagna';
lasagneTitle.style.textShadow = '2px 3px 3px black';


pizza.appendChild(pizzaTitle);
burger.appendChild(burgerTitle);
pasta.appendChild(pastaTitle);
lasagne.appendChild(lasagneTitle);


pizza.style.color = 'white';
pizza.style.fontSize = '4rem';
pizza.style.margin = '3rem';
pizza.style.marginTop = '50px';
pizza.style.border = '1px solid white';
pizza.style.padding = '40px';
pizza.style.width = '16rem';
pizza.style.textAlign = 'center';
pizza.style.backgroundImage = 'url("https://www.restu.cz/ir/restaurant/333/333c249807fce28a920a2504e2706d63--cxc400.jpg")';
pizza.style.backgroundPosition = 'center';
pizza.style.backgroundRepeat = 'no-repeat';
pizza.style.backgroundSize = 'cover';


burger.style.color = 'white';
burger.style.fontSize = '4rem';
burger.style.margin = '3rem';
burger.style.marginTop = '50px';
burger.style.border = '1px solid white';
burger.style.padding = '40px';
burger.style.width = '16rem';
burger.style.textAlign = 'center';
burger.style.backgroundImage = 'url("https://media1.s-nbcnews.com/i/newscms/2019_21/2870431/190524-classic-american-cheeseburger-ew-207p_d9270c5c545b30ea094084c7f2342eb4.jpg")';
burger.style.backgroundPosition = 'center';
burger.style.backgroundRepeat = 'no-repeat';
burger.style.backgroundSize = 'cover';

pasta.style.color = 'white';
pasta.style.fontSize = '4rem';
pasta.style.margin = '3rem';
pasta.style.marginTop = '50px';
pasta.style.border = '1px solid white';
pasta.style.padding = '40px';
pasta.style.width = '16rem';
pasta.style.textAlign = 'center';
pasta.style.backgroundImage = 'url("https://www.bowlofdelicious.com/wp-content/uploads/2020/08/bruschetta-pasta-square.jpg")';
pasta.style.backgroundPosition = 'center';
pasta.style.backgroundRepeat = 'no-repeat';
pasta.style.backgroundSize = 'cover';

lasagne.style.color = 'white';
lasagne.style.fontSize = '4rem';
lasagne.style.margin = '3rem';
lasagne.style.marginTop = '50px';
lasagne.style.border = '1px solid white';
lasagne.style.padding = '40px';
lasagne.style.width = '16rem';
lasagne.style.textAlign = 'center';
lasagne.style.backgroundImage = 'url("https://assets.myfoodandfamily.com/adaptivemedia/rendition/191728_3000x2000.jpg?id=b377e34b56ddab8875671cd073447372ce610184&ht=650&wd=1004&clid=pim")';
lasagne.style.backgroundPosition = 'center';
lasagne.style.backgroundRepeat = 'no-repeat';
lasagne.style.backgroundSize = 'cover';


// itemsDiv.style.backgroundImage = 'url("https://sfwallpaper.com/images/black-smoke-wallpaper-8.jpg")';
// itemsDiv.style.backgroundPosition = 'center';
// itemsDiv.style.backgroundRepeat = 'no-repeat';
// itemsDiv.style.backgroundSize = 'cover';
itemsDiv.style.marginTop = '0px';
itemsDiv.style.height = '60rem';
itemsDiv.style.display = 'flex';
itemsDiv.style.flexDirection = 'row';
itemsDiv.style.justifyContent = 'center';

document.body.style.backgroundImage = 'url("https://sfwallpaper.com/images/black-smoke-wallpaper-8.jpg")';
document.body.style.backgroundPosition = 'center';
document.body.style.backgroundRepeat = 'no-repeat';
document.body.style.backgroundSize = 'cover';


menuDiv.appendChild(homeBtn);
menuDiv.appendChild(menuBtn);
menuDiv.appendChild(contactBtn);

div.appendChild(menuDiv);
div.appendChild(itemsDiv);

itemsDiv.appendChild(pizza);
itemsDiv.appendChild(burger);
itemsDiv.appendChild(pasta);
itemsDiv.appendChild(lasagne);


pizza.appendChild(cheese);
pizza.appendChild(pepperoni);

burger.appendChild(cheeseburger);
burger.appendChild(woodstock);

pasta.appendChild(spaghetti);
pasta.appendChild(carbonara);

lasagne.appendChild(meatLover);
lasagne.appendChild(vegetarian);
