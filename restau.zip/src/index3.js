const div = document.getElementById('content');
const homeBtn = document.createElement('button');
const menuBtn = document.createElement('button');
const contactBtn = document.createElement('button');
const menuDiv = document.createElement('div');
const page = document.createElement('div');


menuDiv.style.display = 'flex';
menuDiv.style.justifyContent = 'center';
menuDiv.style.alignItems = 'center';
menuDiv.style.backgroundColor = 'rgb(79, 79, 79)';
menuDiv.style.marginBottom ='0px';


homeBtn.textContent = 'Home';
homeBtn.className = 'navBtn';
homeBtn.style.width = '50rem';
homeBtn.style.padding='1rem';
homeBtn.style.textShadow = '2px 2px 2px black';
homeBtn.style.marginLeft = '3rem';
homeBtn.style.marginRight = '3rem';
homeBtn.style.fontSize = '30px';
homeBtn.style.letterSpacing = '10px';
homeBtn.style.backgroundColor = 'rgb(79, 79, 79)';
homeBtn.style.color = 'white';
homeBtn.style.border = 'none';
homeBtn.style.outline = 'none';
homeBtn.style.cursor = 'pointer';

menuBtn.textContent = 'Menu';
menuBtn.className = 'navBtn';
menuBtn.style.width = '50rem';
menuBtn.style.textShadow = '2px 2px 2px black';
menuBtn.style.padding = '1rem';
menuBtn.style.marginLeft = '7rem';
menuBtn.style.marginRight = '7rem';
menuBtn.style.fontSize = '30px';
menuBtn.style.letterSpacing = '10px';
menuBtn.style.backgroundColor = 'rgb(79, 79, 79)';
menuBtn.style.color = 'white';
menuBtn.style.border = 'none';
menuBtn.style.outline = 'none';
menuBtn.style.cursor = 'pointer';

contactBtn.textContent = 'Contact us';
contactBtn.className = 'navBtn';
contactBtn.style.width = '50rem';
contactBtn.style.textShadow = '2px 2px 2px black';
contactBtn.style.padding = '1rem';
contactBtn.style.marginLeft = '3rem';
contactBtn.style.marginRight = '3rem';
contactBtn.style.fontSize = '30px';
contactBtn.style.letterSpacing = '10px';
contactBtn.style.backgroundColor = 'rgb(79, 79, 79)';
contactBtn.style.color = 'white';
contactBtn.style.border = 'none';
contactBtn.style.outline = 'none';
contactBtn.style.cursor = 'pointer';

homeBtn.addEventListener('click', ()=>{
    document.location.href = 'index.html';
})

menuBtn.addEventListener('click', ()=>{
    document.location.href = 'menu.html';
})

contactBtn.addEventListener('click', ()=>{
    document.location.href = 'contact.html';
})

document.body.style.backgroundImage = 'url("https://sfwallpaper.com/images/black-smoke-wallpaper-8.jpg")';
document.body.style.backgroundPosition = 'center';
document.body.style.backgroundRepeat = 'no-repeat';
document.body.style.backgroundSize = 'cover';


const itemsDiv = document.createElement('div');
const map = document.createElement('img');
const details = document.createElement('div');


details.style.border = '3px solid white';
details.style.borderRadius = '5px';
details.style.backgroundColor = 'rgb(130, 130, 130)';
details.style.width = '30rem';
details.style.height = '40rem';
details.style.margin = '2rem';

const emailTag = document.createElement('p');
emailTag.textContent = 'Our email is: ';
emailTag.style.fontSize = '2rem';
emailTag.style.color = 'white';
emailTag.style.textShadow = '2px 2px 1px black';
emailTag.style.marginLeft = '1rem';
emailTag.style.fontWeight = '1000';

const email = document.createElement('p');
email.textContent = 'greatfood@kordys.com';
email.style.marginTop = '4rem';
email.style.color = 'white';
email.style.textAlign = 'center';
email.style.textShadow = '2px 2px 1px black';
email.style.fontSize = '2rem';
email.style.fontWeight = '1000';

const lineOne = document.createElement('p');
lineOne.textContent = 'Mage quarter 673';
lineOne.style.textAlign = 'center';
lineOne.style.color = 'white';
lineOne.style.textShadow = '2px 2px 1px black';
lineOne.style.marginTop = '7rem';
lineOne.style.fontSize = '3rem';
lineOne.style.fontWeight = '1000';

const lineTwo = document.createElement('p');
lineTwo.textContent = 'Undercity';
lineTwo.style.textAlign = 'center';
lineTwo.style.fontSize = '3rem';
lineTwo.style.color = 'white';
lineTwo.style.textShadow = '2px 2px 1px black';
lineTwo.style.fontWeight = '1000';

const lineThree = document.createElement('p');
lineThree.textContent = '897 34';
lineThree.style.textAlign = 'center';
lineThree.style.fontSize = '3rem';
lineThree.style.color = 'white';
lineThree.style.textShadow = '2px 2px 1px black';
lineThree.style.fontWeight = '1000';

details.appendChild(emailTag);
details.appendChild(email);
details.appendChild(lineOne);
details.appendChild(lineTwo);
details.appendChild(lineThree);



itemsDiv.style.display = 'flex';
itemsDiv.style.alignItems = 'center';
itemsDiv.style.justifyItems = 'center';
itemsDiv.style.margin = '3rem';
itemsDiv.style.marginTop = '6rem';
itemsDiv.style.flexDirection = 'row';
itemsDiv.style.justifyContent = 'center';
itemsDiv.style.border = 'none';
itemsDiv.style.outline = 'none';

map.style.backgroundImage = 'url("https://wow.zamimg.com/uploads/blog/images/17323-one-map-to-rule-them-all-classic-azeroth-detailed-map-edit-by-rhianolord.jpg")';
// map.style.backgroundSize = '100%';
map.style.width = '60rem';
map.style.display = 'flex';
// map.style.alignItems = 'flex-end';
// map.style.justifyContent = 'flex-end';
map.style.height = '45rem';
map.style.backgroundPosition = 'center';
map.style.backgroundRepeat = 'no-repeat';
map.style.backgroundSize = 'contain';
map.style.border = 'none';
map.style.outline = 'none';




itemsDiv.appendChild(details);
itemsDiv.appendChild(map);


menuDiv.appendChild(homeBtn);
menuDiv.appendChild(menuBtn);
menuDiv.appendChild(contactBtn);

div.appendChild(page);
div.appendChild(menuDiv);
div.appendChild(itemsDiv);




